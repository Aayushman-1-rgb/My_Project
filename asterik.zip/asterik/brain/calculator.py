"""Safe arithmetic for ASTERIK - standard library only.

This module never uses eval() or exec(). Expressions are tokenized and
parsed by a small hand-written recursive-descent parser that only accepts
numbers, parentheses, and the operators  +  -  *  /  //  %  **

Anything else (letters, quotes,underscores, unknown symbols) raises CalcError,
so hostile input like  __import__('os')  can never execute.
"""

import re


class CalcError(ValueError):
    """Raised when an expression is invalid or unsafe."""


# A number (int or float) or an operator/parenthesis (two-char // and **
# must be matched before the single-char ones).
_TOKEN_RE = re.compile(r"\s*(?:(\d+\.?\d*|\.\d+)|(//|\*\*|[-+*/%()]))")


def tokenize(text):
    """Split text into ('num', float) and ('op', str) tokens."""
    tokens = []
    pos = 0
    length = len(text)
    while pos < length:
        if text[pos:].strip() == "":
            break
        match = _TOKEN_RE.match(text, pos)
        if not match:
            raise CalcError("Only numbers and + - * / // % ** ( ) are allowed.")
        if match.group(1) is not None:
            tokens.append(("num", float(match.group(1))))
        else:
            tokens.append(("op", match.group(2)))
        pos = match.end()
    return tokens


# ---------------------------------------------------------------------
# Grammar (lowest to highest precedence):
#   expression := term (('+' | '-') term)*
#   term       := unary (('*' | '/' | '//' | '%') unary)*
#   unary      := '-' unary | power
#   power      := primary ('**' unary)?
#   primary    := NUMBER | '(' expression ')'
# ---------------------------------------------------------------------

def _parse_expression(tokens, pos):
    value = _parse_term(tokens, pos)
    while pos[0] < len(tokens) and tokens[pos[0]] in (("op", "+"), ("op", "-")):
        operator = tokens[pos[0]][1]
        pos[0] += 1
        right = _parse_term(tokens, pos)
        value = value + right if operator == "+" else value - right
    return value


def _parse_term(tokens, pos):
    value = _parse_unary(tokens, pos)
    while pos[0] < len(tokens) and tokens[pos[0]][0] == "op" and \
            tokens[pos[0]][1] in ("*", "/", "//", "%"):
        operator = tokens[pos[0]][1]
        pos[0] += 1
        right = _parse_unary(tokens, pos)
        if operator == "*":
            value = value * right
        elif operator == "/":
            if right == 0:
                raise CalcError("Cannot divide by zero.")
            value = value / right
        elif operator == "//":
            if right == 0:
                raise CalcError("Cannot divide by zero.")
            value = value // right
        else:
            if right == 0:
                raise CalcError("Cannot take modulo zero.")
            value = value % right
    return value


def _parse_unary(tokens, pos):
    if pos[0] < len(tokens) and tokens[pos[0]] == ("op", "-"):
        pos[0] += 1
        return -_parse_unary(tokens, pos)
    return _parse_power(tokens, pos)


def _parse_power(tokens, pos):
    base = _parse_primary(tokens, pos)
    if pos[0] < len(tokens) and tokens[pos[0]] == ("op", "**"):
        pos[0] += 1
        exponent = _parse_unary(tokens, pos)  # right-associative; allows 2 ** -1
        return base ** exponent
    return base


def _parse_primary(tokens, pos):
    if pos[0] >= len(tokens):
        raise CalcError("Expression ends unexpectedly.")
    token = tokens[pos[0]]
    if token == ("op", "("):
        pos[0] += 1
        value = _parse_expression(tokens, pos)
        if pos[0] >= len(tokens) or tokens[pos[0]] != ("op", ")"):
            raise CalcError("Missing closing parenthesis.")
        pos[0] += 1
        return value
    if token[0] == "num":
        pos[0] += 1
        return token[1]
    raise CalcError("Unexpected symbol '{}'.".format(token[1]))


def evaluate(expression):
    """Evaluate a math expression and return a float. Raises CalcError."""
    tokens = tokenize(expression)
    if not tokens:
        raise CalcError("Nothing to calculate.")
    pos = [0]
    value = _parse_expression(tokens, pos)
    if pos[0] != len(tokens):
        raise CalcError("Unexpected symbol '{}'.".format(tokens[pos[0]][1]))
    return value


def is_math_like(text):
    """True if text contains at least one digit and one math operator."""
    has_digit = any(character.isdigit() for character in text)
    has_operator = any(operator in text for operator in "+-*/%")
    return has_digit and has_operator


def try_evaluate(text):
    """Return (ok, value, error_message). Never raises for bad input."""
    try:
        return True, evaluate(text), None
    except CalcError as error:
        return False, None, str(error)
    except OverflowError:
        return False, None, "That number is too large to compute."


def format_number(value):
    """Show whole numbers without a trailing .0 (4.0 -> '4')."""
    if float(value).is_integer():
        return str(int(value))
    return "{:.10g}".format(value)
