"""Offline conversation for ASTERIK - standard library only.

Handles greetings, identity/purpose questions, graceful replies for
unknown input, and the in-memory session history. No AI model required.
"""

# Exact phrases (after normalize) that count as greetings.
GREETING_EXACT = {
    "hi", "hey", "hello", "hiya", "howdy", "yo", "greetings", "salutations",
    "good morning", "good afternoon", "good evening", "good day",
    "how are you", "how are you doing", "how do you do",
    "how's it going", "how is it going", "whats up", "what's up",
}

# First words that greet when the whole message is short (e.g. "hi there").
GREETING_STARTS = ("hi", "hey", "hello", "howdy", "yo", "greetings")

# Phrases that signal a question about who/what ASTERIK is.
IDENTITY_TRIGGERS = (
    "your name", "who are you", "what are you", "who am i talking",
    "what should i call you", "what can you do", "what do you do",
    "your purpose", "about yourself",
)


def normalize(text):
    """Lowercase, collapse whitespace, and trim trailing punctuation."""
    cleaned = " ".join(text.strip().lower().split())
    return cleaned.rstrip("?!.,;:")


def is_greeting(text):
    """True for short greeting messages like 'hi' or 'good morning?'."""
    cleaned = normalize(text)
    if not cleaned:
        return False
    if cleaned in GREETING_EXACT:
        return True
    words = cleaned.split()
    return len(words) <= 3 and words[0] in GREETING_STARTS


def is_identity_question(text):
    """True for questions about ASTERIK's name, nature, or purpose."""
    cleaned = normalize(text)
    return any(trigger in cleaned for trigger in IDENTITY_TRIGGERS)


def greeting_reply(text, assistant_name):
    """Reply to a greeting, with a slightly different tone for 'how are you'."""
    cleaned = normalize(text)
    wellness = (
        "how are you", "how are you doing", "how do you do",
        "how's it going", "how is it going", "whats up", "what's up",
    )
    if cleaned in wellness:
        return "All systems nominal. Ready when you are - what do you need?"
    return "Greetings. {} online and ready.".format(assistant_name)


def identity_reply(assistant_name, version):
    """Explain who ASTERIK is and what it can do offline."""
    return (
        "I am {name} v{version} - your offline desktop assistant. "
        "In this session I can tell the time and date, run safe calculations "
        "(try: calc 2 * (3 + 4)), review our conversation (history), or "
        "assist with commands (help).".format(name=assistant_name, version=version)
    )


def unknown_reply(assistant_name, session):
    """Graceful fallback for input we cannot answer offline.

    Explains the AI-model requirement once, without nagging, and points
    to what works offline right now. Slight variety based on session
    length so repeated fallbacks do not feel robotic.
    """
    variants = [
        (
            "Open-ended conversation needs an AI model (a free cloud one or "
            "a local one) - enable one later in config.py. Meanwhile, I can: "
            "tell time/date, do math (calc 2 + 2), show 'history', or 'help'."
        ),
        (
            "That is beyond my offline commands. Once an AI provider is "
            "connected via config.py, I will handle chat like this natively. "
            "For now: time, date, calc, history, or help."
        ),
        (
            "No offline rule matches that one. Tip: connecting an AI model in "
            "config.py unlocks real conversation. Until then, try 'help' for "
            "my current capabilities."
        ),
    ]
    return variants[len(session) % len(variants)]


class Session:
    """In-memory conversation history (newest last, capped in size)."""

    def __init__(self, max_entries=100):
        self.max_entries = max_entries
        self._entries = []

    def record(self, speaker, text):
        """Store one message. Empty messages are ignored."""
        cleaned = " ".join(text.strip().split())
        if not cleaned:
            return
        self._entries.append((speaker, cleaned))
        if len(self._entries) > self.max_entries:
            del self._entries[0]

    def recent(self, count=6):
        """Return the last `count` (speaker, text) pairs."""
        return self._entries[-count:]

    def __len__(self):
        return len(self._entries)
