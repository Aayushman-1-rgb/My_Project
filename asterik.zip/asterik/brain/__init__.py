"""Brain package: local intent parsing + provider-independent AI layer."""
