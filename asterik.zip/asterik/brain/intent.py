"""Local command parsing for ASTERIK.

Everything here runs fully offline - no AI provider needed.
To add a new built-in command, add it to COMMANDS (and handle it in main.py).
"""

# Canonical command names and their descriptions (shown by 'help').
COMMANDS = {
    "help": "Show this list of commands.",
    "time": "Show the current local time.",
    "date": "Show the current local date.",
    "calc": "Safe arithmetic, e.g. calc 2 * (3 + 4).",
    "history": "Review the last exchanges in this session.",
    "speak": "Read my most recent response aloud again.",
    "exit": "Quit ASTERIK.",
}

# Alternative spellings that map to a canonical command name.
# (Greetings like 'hello' are handled in brain/conversation.py, not here.)
ALIASES = {
    "quit": "exit",
    "q": "exit",
    "bye": "exit",
    "again": "speak",
    "repeat": "speak",
}

# Whole-phrase aliases (matched against the full normalized input,
# before single-word parsing). This is what makes "read it aloud" work.
PHRASE_ALIASES = {
    "read it aloud": "speak",
    "read that aloud": "speak",
    "say that again": "speak",
    "say it again": "speak",
    "repeat that": "speak",
    "repeat it": "speak",
}

# Trailing punctuation ignored when matching commands/phrases.
_TRAILING_PUNCTUATION = "?!.,;:"


def normalize_for_command(text):
    """Return a normalized *copy* of the input for command matching.

    The copy is trimmed, lowercased, has internal whitespace collapsed,
    and trailing punctuation removed, so "Read it aloud!!!" and
    "  say   that again. " both match. The original text is never
    modified - conversation history keeps exactly what the user typed.
    """
    cleaned = " ".join(str(text).strip().lower().split())
    return cleaned.rstrip(_TRAILING_PUNCTUATION)


def parse(text):
    """Return (command_name_or_None, argument_remainder).

    Matching runs on a normalized copy (see normalize_for_command);
    the original input is left untouched for history.

    - ("help", "")          -> user typed 'help' (or 'help!')
    - ("calc", "2 + 2")     -> user typed 'calc 2 + 2'
    - ("speak", "")         -> 'speak', 'read it aloud', 'say that again.', ...
    - (None, "hi")          -> not a built-in command (greeting, chat, ...)
    - (None, "")            -> empty/whitespace input
    """
    normalized = normalize_for_command(text)
    if not normalized:
        return None, ""

    # Whole-phrase aliases first ("read it aloud", "say that again", ...).
    if normalized in PHRASE_ALIASES:
        return PHRASE_ALIASES[normalized], ""

    words = normalized.split()
    # Punctuation on the first word is ignored too ("speak!", "again?").
    lookup_word = words[0].rstrip(_TRAILING_PUNCTUATION)
    name = ALIASES.get(lookup_word, lookup_word)

    if name in COMMANDS:
        remainder = normalized.split(None, 1)[1].strip() if len(words) > 1 else ""
        return name, remainder

    return None, normalized
