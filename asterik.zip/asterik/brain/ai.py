"""AI-provider layer for ASTERIK.

Design rules:
- The rest of the project calls ask() only; it never talks to a provider
  directly. This keeps ASTERIK provider-independent (free cloud vs local
  model can be swapped later by changing config, not code elsewhere).
- Milestone 1 works fully offline: with AI_ENABLED = False (or no
  provider configured), ask() returns a local fallback message and
  nothing on the network is touched.
"""


class BrainProvider:
    """Interface that every AI backend must implement."""

    name = "base"

    def send_text(self, prompt):
        """Send text to the brain and return its reply as a string."""
        raise NotImplementedError


class OfflineProvider(BrainProvider):
    """Local fallback used when no AI provider is configured."""

    name = "offline"

    def send_text(self, prompt):
        return (
            "AI is disabled, so I cannot think about that yet. "
            "Type 'help' to see what I can do offline."
        )


def get_provider(config):
    """Return the provider selected in config.

    Extend this function later to return FreeCloudProvider(config) or
    LocalModelProvider(config) based on config.AI_PROVIDER.
    """
    if not getattr(config, "AI_ENABLED", False):
        return OfflineProvider()
    # Providers are not implemented in milestone 1.
    return OfflineProvider()


def ask(config, text):
    """Send text to the configured brain and return its reply."""
    provider = get_provider(config)
    return provider.send_text(text)
