# ASTERIK

A personal AI assistant for Windows, built in Python. Designed to work
fully offline by default, with optional AI brains (free cloud or local
models) that can be swapped without rewriting the project.

## Status

**Milestone 2.2 (v0.2.1)** - reliable speech + repeat-last-response:
- Built-in commands: `help`, `time`, `date`, `calc`, `history`, `speak`, `exit`
- Greets you ("hi", "good morning", "how are you")
- Answers questions about its name and purpose
- Safe arithmetic (no `eval`) - with or without the `calc` prefix
- In-memory session history (`history` command)
- Graceful fallback for unknown input (honest about needing an AI model,
  without nagging)
- **Spoken replies** via offline Windows SAPI5 (`pyttsx3`) - always
  printed as text too; automatic text-only fallback on any voice failure
- **Every** response goes through one shared output function (print +
  speech), so greetings, commands, math, and fallbacks are all spoken
- **`speak`** command (aliases: `read it aloud`, `say that again`,
  `again`, `repeat that`) re-reads the most recent response aloud

Not yet implemented (planned): microphone input, real AI providers,
computer automation, desktop HUD.

## Requirements

- Python 3.8 or newer (developed with `C:\Python314\python.exe`)
- `pyttsx3` for voice output (free, offline, no API keys)

## Setup

1. Open a terminal (Command Prompt or PowerShell).
2. Go to the project folder:

       cd "C:\Users\Sandeep Kumar Yadav\Documents\asterik"

3. Install the voice dependency (one-time):

       C:\Python314\python.exe -m pip install pyttsx3

4. Start ASTERIK:

       C:\Python314\python.exe main.py

## Voice settings

In `config.py`:

| Setting | Default | Meaning |
|---|---|---|
| `SPEAK_RESPONSES` | `True` | `False` = text-only, no audio at all |
| `SPEECH_RATE` | `175` | Words per minute (Windows default ~200) |
| `SPEECH_MAX_CHARS` | `300` | Long replies (help/history) are truncated for speech at a word boundary |

Duplicate consecutive replies are spoken only once (use the `speak`
command to force a re-read). Every utterance gets a fresh speech engine
internally - this works around a Windows pyttsx3 issue where the engine
silently stops playing after the first reply. If the speech engine fails
at any point, ASTERIK prints one notice - "(Voice output unavailable -
continuing in text-only mode.)" - and keeps working.

## Example interactions

    You: hi
    ASTERIK> Greetings. ASTERIK online and ready.

    You: how are you?
    ASTERIK> All systems nominal. Ready when you are - what do you need?

    You: what is your name?
    ASTERIK> I am ASTERIK v0.1.0 - your offline desktop assistant. ...

    You: time
    ASTERIK> Local time: 14:32.

    You: date
    ASTERIK> Today is Saturday, 17 October 2026.

    You: calc 2 * (3 + 4)
    ASTERIK> 2 * (3 + 4) = 14

    You: 100 / 3
    ASTERIK> 100 / 3 = 33.3333333333

    You: tell me a story
    ASTERIK> Open-ended conversation needs an AI model (a free cloud one or
    a local one) - enable one later in config.py. Meanwhile, I can: tell
    time/date, do math (calc 2 + 2), show 'history', or 'help'.

    You: history
    ASTERIK> Recent exchanges:
      you: hi
      ASTERIK: Greetings. ASTERIK online and ready.
      ...

    You: read it aloud
    ASTERIK> Recent exchanges: ...   (the previous response, re-spoken)

    You: exit
    ASTERIK> Goodbye. Systems standing by.

## Troubleshooting voice

| Symptom | Cause / fix |
|---|---|
| No sound, but you see "(Voice output unavailable - continuing in text-only mode.)" | Windows SAPI5 failed or `pyttsx3` is broken. ASTERIK keeps working as text. Verify the install: `C:\Python314\python.exe -c "import pyttsx3; pyttsx3.init().say('test'); pyttsx3.init().runAndWait()"` |
| No sound and no warning | `SPEAK_RESPONSES = False` in `config.py`, or the reply was an exact repeat of the previous one (spoken once by design) |
| Speech too fast/slow | Adjust `SPEECH_RATE` in `config.py` (try 140-200) |
| Wrong voice | Windows Settings > Time & Language > Speech > Voice packages - install another SAPI5 voice |
| First reply is slow | The engine initializes lazily on the first spoken reply; later replies are fast |
| `pip` installs to the wrong Python | Always use `C:\Python314\python.exe -m pip install pyttsx3` so it matches the interpreter that runs ASTERIK |

## How to run the tests

From the project folder (standard library `unittest`, no installs):

    python -m unittest discover -s tests -t . -v

## Safety notes

- Arithmetic is parsed by a hand-written parser in `brain/calculator.py`.
  `eval()`/`exec()` are never used, so input like `__import__('os')` is
  rejected, not executed.
- No shell execution or computer automation exists yet; the `automation/`
  package is an empty placeholder by design until its allowlist and
  confirmation gate are implemented.

## Project structure

    asterik/
    |-- main.py            Entry point + command loop
    |-- config.py          Settings (AI on/off, provider choice)
    |-- brain/
    |   |-- intent.py      Local command parsing (offline)
    |   |-- ai.py          Provider-independent AI layer + offline fallback
    |-- voice/             (planned) speech recognition + TTS
    |-- automation/        (planned) restricted, confirmed computer actions
    |-- hud/               (planned) desktop HUD display layer
    |-- utils/             (planned) shared helpers like logging
    |-- tests/             (planned) feature tests

## Adding a built-in command

1. Add its name and description to `COMMANDS` in `brain/intent.py`.
2. Add a handler function in `main.py` and register it in `HANDLERS`.

## Switching AI providers (future)

Implement a class with a `send_text(prompt)` method in `brain/ai.py`
(or a future `brain/providers/` folder), return it from `get_provider()`
based on `config.AI_PROVIDER`, and set `config.AI_ENABLED = True`.
No other file needs to change.
