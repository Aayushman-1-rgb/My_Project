"""HUD package: future desktop heads-up display layer.

The HUD will observe assistant events (heard input, decisions, actions)
without brain/voice/automation ever depending on it.
"""
