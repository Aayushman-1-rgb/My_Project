"""Offline text-to-speech for ASTERIK - Windows SAPI5 via pyttsx3.

Design rules:
- Printing always happens in main.py; speech is additive, never required.
- Any failure (missing package, broken audio device, engine error) disables
  speech for the rest of the session. The command loop never crashes.
- A fresh engine is created for every utterance. A long-lived pyttsx3
  engine silently stops playing after the first reply on Windows once
  input() blocks the COM message pump - recreating it is the reliable fix.
- Consecutive identical replies are spoken once, not twice (unless
  force=True, used by the 'speak' repeat command).
- Long replies (help, history) are truncated at a word boundary so the
  speaker does not read an essay aloud.
- The engine is created lazily and only when speech is enabled.
"""

import config as _default_config


def _clean(text):
    """Collapse newlines/spaces into a single spoken line."""
    return " ".join(str(text).split())


def _truncate(text, max_chars):
    """Cut at a word boundary and add an ellipsis if text is too long."""
    if max_chars <= 0 or len(text) <= max_chars:
        return text
    cut = text[:max_chars]
    if " " in cut:
        cut = cut.rsplit(" ", 1)[0]
    return cut + "..."


def _create_default_engine():
    """Initialize the system speech engine (Windows SAPI5)."""
    import pyttsx3
    return pyttsx3.init()


class Speaker:
    """Speaks replies aloud. Safe to construct anywhere; lazy engine init.

    engine_factory: injectable for tests (a callable returning a fake
    engine with .say(), .runAndWait(), .setProperty()). Defaults to the
    real pyttsx3 engine.
    """

    def __init__(self, enabled=True, rate=175, max_chars=300,
                 engine_factory=None):
        self.enabled = bool(enabled)
        self.rate = rate
        self.max_chars = max_chars
        self._factory = engine_factory or _create_default_engine
        self._failed = False       # sticky: True = text-only from now on
        self._last_spoken = ""

    # -- public API ----------------------------------------------------

    def speak(self, text, force=False):
        """Speak one reply. Returns True if audio was triggered.

        force=True bypasses the duplicate check (used by the 'speak'
        repeat command). Never raises: any error flips the speaker to
        text-only mode.
        """
        if not self.enabled or self._failed:
            return False

        cleaned = _truncate(_clean(text), self.max_chars)
        if not cleaned:
            return False  # never speak empty text
        if not force and cleaned == self._last_spoken:
            return False  # exact repeat of the previous reply

        try:
            engine = self._factory()
            engine.setProperty("rate", self.rate)
            engine.say(cleaned)
            engine.runAndWait()
            stop = getattr(engine, "stop", None)
            if callable(stop):
                stop()  # release engine resources promptly
        except Exception:
            self._disable_after_failure()
            return False

        self._last_spoken = cleaned
        return True

    def set_enabled(self, enabled):
        """Toggle speech at runtime (e.g. a future 'mute' command)."""
        self.enabled = bool(enabled)
        self._last_spoken = ""

    # -- internals -----------------------------------------------------

    def _disable_after_failure(self):
        """One warning, then silent text-only mode forever."""
        self._failed = True
        self._engine = None
        print("(Voice output unavailable - continuing in text-only mode.)")


# -- module-level speaker (one per process) -------------------------------

_speaker = None


def get_speaker(speech_config=_default_config):
    """Return the shared Speaker built from config, creating it once."""
    global _speaker
    if _speaker is None:
        _speaker = Speaker(
            enabled=getattr(speech_config, "SPEAK_RESPONSES", True),
            rate=getattr(speech_config, "SPEECH_RATE", 175),
            max_chars=getattr(speech_config, "SPEECH_MAX_CHARS", 300),
        )
    return _speaker


def reset_speaker_for_tests():
    """Drop the shared speaker so tests can build a fresh one."""
    global _speaker
    _speaker = None