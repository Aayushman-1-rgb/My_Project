"""Voice package: speech recognition (listener) and TTS (speaker).

Voice output lives in voice/speaker.py. Microphone input is not
implemented yet (and is not needed for ASTERIK v0.2).
"""
