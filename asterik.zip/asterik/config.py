"""Central settings for ASTERIK. Edit values here, not in the code."""

ASSISTANT_NAME = "ASTERIK"
VERSION = "0.2.2"

# ---------------------------------------------------------------------
# AI provider
# Milestone 1 is fully offline. When a provider is added later (free
# cloud or local model), flip AI_ENABLED to True and set AI_PROVIDER.
# ---------------------------------------------------------------------
AI_ENABLED = False    # True = non-command input goes to a real brain
AI_PROVIDER = "none"  # Future options: "free_cloud" or "local_model"

# ---------------------------------------------------------------------
# Voice output (offline, free - Windows SAPI5 via pyttsx3)
# ASTERIK always prints replies; speech is additive. If the speech
# engine fails, ASTERIK silently continues in text-only mode.
# ---------------------------------------------------------------------
SPEAK_RESPONSES = True   # False = text-only, no audio at all
SPEECH_RATE = 175        # Words per minute (Windows default is ~200)
SPEECH_MAX_CHARS = 300   # Truncate long replies (help/history) for speech
