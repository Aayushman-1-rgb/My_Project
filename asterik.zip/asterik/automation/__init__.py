"""Automation package: restricted, confirmation-gated computer actions. Not implemented yet."""
