"""ASTERIK - personal AI assistant. Entry point.

Run from the project folder with:  python main.py

Fully offline: built-in commands, greetings, safe arithmetic, and a
session history. Replies are spoken aloud via voice/speaker.py
(offline Windows SAPI5 through pyttsx3) and always printed as text.
Open-ended chat is routed to brain.ai.ask() only if AI is enabled.
"""

from datetime import datetime

import config
from brain import ai
from brain import calculator
from brain import conversation
from brain import intent
from voice import speaker as speaker_module

# The most recent response ASTERIK printed/spoken (for the 'speak' command).
_last_reply = ""


def reply(text, force_speak=False):
    """The single output path: print the reply, then speak the same text.

    Every response - startup, commands, greetings, math, fallbacks -
    goes through this function, so nothing is printed without also being
    offered to the speech engine. Empty text is printed as-is but never
    tracked or spoken. Speech failures never interrupt text.
    """
    global _last_reply
    print("{}> {}".format(config.ASSISTANT_NAME, text))
    if not str(text).strip():
        return  # never track or speak empty output
    _last_reply = text
    try:
        speaker_module.get_speaker(config).speak(text, force=force_speak)
    except Exception:
        # Belt-and-braces: printing already happened; voice is optional.
        pass


def last_reply_text():
    """Return the most recent response ASTERIK gave (may be empty)."""
    return _last_reply


def is_empty_input(text):
    """True for empty or whitespace-only input.

    This is intentional, silent behavior: no warning, no error message,
    no response, no speech, no history entry - just return to the prompt.
    """
    return not str(text).strip()


# ----------------------------------------------------------------------
# Built-in command handlers. Each takes (argument_text, session)
# and returns a string to display (or None if it printed itself).
# ----------------------------------------------------------------------

def handle_help(argument, session):
    lines = ["Built-in commands:"]
    for name, description in sorted(intent.COMMANDS.items()):
        lines.append("  {:<8} {}".format(name, description))
    lines.append("  I also understand simple greetings (hi, good morning, "
                 "how are you)")
    lines.append("  and questions like 'what is your purpose?'.")
    lines.append("  Try math: calc 2 * (3 + 4)")
    return "\n".join(lines)


def handle_time(argument, session):
    now = datetime.now()
    return "Local time: {}:{:02d}.".format(now.strftime("%H"), now.minute)


def handle_date(argument, session):
    now = datetime.now()
    return "Today is {}, {} {} {}.".format(
        now.strftime("%A"), now.day, now.strftime("%B"), now.year)


def handle_calc(argument, session):
    if not argument:
        return "Usage: calc 2 * (3 + 4). Supports + - * / // % ** and ( )."
    ok, value, error = calculator.try_evaluate(argument)
    if ok:
        return "{} = {}".format(argument, calculator.format_number(value))
    return "Cannot compute that: {}".format(error)


def handle_history(argument, session):
    entries = session.recent(6)
    if not entries:
        return "No conversation recorded yet in this session."
    lines = ["Recent exchanges:"]
    for speaker, text in entries:
        prefix = "you" if speaker == "user" else config.ASSISTANT_NAME
        lines.append("  {}: {}".format(prefix, text))
    return "\n".join(lines)


def handle_exit(argument, session):
    return "Goodbye. Systems standing by."


def handle_speak(argument, session):
    """Repeat the most recent response aloud (aliases: 'read it aloud',
    'say that again', 'again', ...)."""
    previous = last_reply_text()
    if not previous:
        return "I have not said anything yet in this session."
    return previous


# Keys must match names in intent.COMMANDS.
HANDLERS = {
    "help": handle_help,
    "time": handle_time,
    "date": handle_date,
    "calc": handle_calc,
    "history": handle_history,
    "speak": handle_speak,
    "exit": handle_exit,
}


def respond(user_text, session):
    """Turn user text into an assistant reply string (offline paths only)."""
    command, remainder = intent.parse(user_text)

    if command is not None:
        handler = HANDLERS.get(command)
        if handler is not None:
            return handler(remainder, session)
        return "Command '{}' is recognized but not implemented yet.".format(command)

    if conversation.is_greeting(user_text):
        return conversation.greeting_reply(user_text, config.ASSISTANT_NAME)

    if conversation.is_identity_question(user_text):
        return conversation.identity_reply(config.ASSISTANT_NAME, config.VERSION)

    # Bare math like "2 + 2" (no 'calc' prefix needed).
    if calculator.is_math_like(user_text):
        ok, value, error = calculator.try_evaluate(user_text)
        if ok:
            return "{} = {}".format(user_text.strip(), calculator.format_number(value))
        return "Cannot compute that: {}".format(error)

    # Graceful fallback: explains the AI-model requirement without nagging.
    # If an AI provider is ever enabled in config.py, it answers here instead.
    if config.AI_ENABLED:
        return ai.ask(config, user_text.strip())
    return conversation.unknown_reply(config.ASSISTANT_NAME, session)


def main():
    """Main command loop: read input -> route to command or offline brain."""
    session = conversation.Session()
    print("{} v{} (offline mode)".format(config.ASSISTANT_NAME, config.VERSION))
    print("Type 'help' for commands. I understand greetings, time, date, "
          "and safe math.\n")
    reply("Systems online. How can I assist?")

    running = True
    while running:
        try:
            user_text = input("You: ")
        except (EOFError, KeyboardInterrupt):
            # Exit QUIETLY on Ctrl+C / Ctrl+Z / closed input stream.
            # Synthesizing an 'exit' command here used to make ASTERIK
            # suddenly speak a goodbye the user never asked for.
            print()
            break

        if is_empty_input(user_text):
            # Intentional, silent: no message, no speech, no history.
            # Just show the next 'You: ' prompt.
            continue

        # History keeps the ORIGINAL text; command matching uses a
        # normalized copy inside intent.parse().
        session.record("user", user_text)
        response = respond(user_text, session)
        session.record("assistant", response)
        # The 'speak' command re-hears the last reply, so bypass dedupe.
        command_name = intent.parse(user_text)[0]
        reply(response, force_speak=(command_name == "speak"))

        if command_name == "exit":
            running = False


if __name__ == "__main__":
    main()
