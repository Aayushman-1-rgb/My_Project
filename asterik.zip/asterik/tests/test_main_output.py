"""Tests for main.py's shared output path (reply) and the 'speak' repeat.

Uses a mocked speaker module - no audio hardware, no pyttsx3 needed.
"""

import unittest

import main
from brain import conversation
from brain import intent
from voice import speaker as speaker_module


class RecordingSpeaker:
    """Stands in for voice.speaker.Speaker; records every speak call."""

    def __init__(self):
        self.calls = []  # list of (text, force)

    def speak(self, text, force=False):
        self.calls.append((text, force))
        return True


class OutputPathTestCase(unittest.TestCase):
    """Base: swaps in a RecordingSpeaker and resets main's last-reply."""

    def setUp(self):
        self.recorder = RecordingSpeaker()
        self._original = speaker_module._speaker
        speaker_module._speaker = self.recorder
        main._last_reply = ""

    def tearDown(self):
        speaker_module._speaker = self._original
        main._last_reply = ""


class TestReplyIsSharedOutput(OutputPathTestCase):

    def test_reply_prints_and_speaks_same_text(self):
        main.reply("Greetings. ASTERIK online and ready.")
        self.assertEqual(self.recorder.calls,
                         [("Greetings. ASTERIK online and ready.", False)])

    def test_every_offline_response_is_spoken(self):
        """Greetings, identity, math, help, and fallback all speak."""
        session = conversation.Session()
        samples = [
            "hi",                       # greeting
            "how are you",              # wellness greeting
            "what is your name?",       # identity
            "time",                     # command
            "date",                     # command
            "2 + 2",                    # bare math
            "calc 10 / 4",              # calc command
            "history",                  # command
            "help",                     # command
            "quantum flux capacitor",   # unknown fallback
        ]
        for text in samples:
            response = main.respond(text, session)
            main.reply(response)
        # One speak call per response - nothing silently text-only.
        self.assertEqual(len(self.recorder.calls), len(samples))
        for spoken_text, force in self.recorder.calls:
            self.assertTrue(spoken_text)   # never empty
            self.assertFalse(force)        # normal replies are not forced

    def test_speech_failure_does_not_break_reply(self):
        class ExplodingSpeaker:
            def speak(self, text, force=False):
                raise RuntimeError("boom")

        speaker_module._speaker = ExplodingSpeaker()
        main.reply("This must still print.")  # must not raise
        self.assertEqual(main.last_reply_text(), "This must still print.")

    def test_empty_reply_is_not_tracked_or_spoken(self):
        main.reply("A real reply.")
        main.reply("   ")  # empty output: printed, but nothing new tracked
        self.assertEqual(main.last_reply_text(), "A real reply.")
        self.assertEqual(len(self.recorder.calls), 1)  # only the real reply

    def test_history_preserves_original_input(self):
        """Matching is normalized; history keeps exactly what was typed
        (original casing and punctuation, only whitespace collapsed)."""
        session = conversation.Session()
        session.record("user", "  Read   it ALoud!!!  ")
        speaker, text = session.recent(1)[0]
        self.assertEqual((speaker, text), ("user", "Read it ALoud!!!"))
        # And that original still matches the 'speak' command.
        self.assertEqual(intent.parse(text)[0], "speak")


class TestEmptyInputIsSilent(OutputPathTestCase):
    """Empty/whitespace input is intentionally ignored: no warning, no
    error, no response, no speech, no history entry, and it must NEVER
    trigger the repeat-last-response mechanism."""

    def test_empty_and_whitespace_detected(self):
        for text in ("", "   ", "\t", " \n ", "\n"):
            self.assertTrue(main.is_empty_input(text), repr(text))
        for text in ("hi", "speak", "0"):
            self.assertFalse(main.is_empty_input(text), repr(text))

    def test_empty_input_never_speaks_or_repeats(self):
        session = conversation.Session()
        # A real reply happens first, so there IS a last response.
        main.reply("Four.")
        self.assertEqual(len(self.recorder.calls), 1)

        # The loop's empty-input guard skips respond()/reply() entirely,
        # so nothing new is spoken and the old reply is not re-triggered.
        for text in ("", "   "):
            if main.is_empty_input(text):
                continue
            self.fail("empty input must be skipped by the loop guard")

        self.assertEqual(len(self.recorder.calls), 1)  # unchanged
        # Last reply is still the real one - a later explicit repeat works.
        repeat = main.respond("read it aloud", session)
        self.assertEqual(repeat, "Four.")
        main.reply(repeat, force_speak=True)
        self.assertEqual(self.recorder.calls[-1], ("Four.", True))

    def test_empty_input_not_recorded_in_history(self):
        session = conversation.Session()
        session.record("user", "hi")
        session.record("assistant", "Greetings.")
        # Mirror the loop: empty lines never reach session.record().
        for text in ("", "   "):
            if main.is_empty_input(text):
                continue
            session.record("user", text)
        self.assertEqual(len(session), 2)
        self.assertEqual([entry for entry in session.recent(10)
                          if entry[0] == "user"],
                         [("user", "hi")])


class TestSpeakRepeatCommand(OutputPathTestCase):

    def test_speak_repeats_last_reply_forced(self):
        session = conversation.Session()
        response = main.respond("time", session)
        main.reply(response, force_speak=False)

        repeat = main.respond("speak", session)
        self.assertEqual(repeat, response)
        main.reply(repeat, force_speak=True)
        # Last call repeats the identical text with force=True.
        self.assertEqual(self.recorder.calls[-1], (response, True))

    def test_speak_without_prior_reply(self):
        session = conversation.Session()
        message = main.respond("read it aloud", session)
        self.assertIn("not said anything", message)

    def test_speak_aliases_route_to_repeat(self):
        session = conversation.Session()
        main.reply("Four.")
        for phrase in ("speak", "read it aloud", "Read it aloud!!!",
                       "say that again", "say that again.", "again"):
            self.assertEqual(main.respond(phrase, session), "Four.", phrase)

    def test_repeat_is_the_response_not_the_user_command(self):
        """'read it aloud' must re-send the last ASTERIK reply, not the
        text the user typed to ask for the repeat."""
        session = conversation.Session()
        greeting = main.respond("hi", session)
        main.reply(greeting)
        # User then asks for the repeat with punctuation.
        repeat = main.respond("Read it aloud!!!", session)
        self.assertEqual(repeat, greeting)
        self.assertNotIn("aloud", repeat.lower())


if __name__ == "__main__":
    unittest.main()