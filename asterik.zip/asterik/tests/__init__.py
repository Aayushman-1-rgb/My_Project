"""Tests package for ASTERIK.

Run from the project folder with:  python -m unittest discover -s tests -t .
(No third-party packages needed - standard library unittest only.)
"""
