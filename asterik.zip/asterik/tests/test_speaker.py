"""Tests for voice/speaker.py using a mocked engine (no audio hardware).

Run from the project folder with:  python -m unittest discover -s tests -t .
"""

import unittest

from voice import speaker as speaker_module


class FakeEngine:
    """Stands in for a pyttsx3 engine; records what would be spoken."""

    def __init__(self):
        self.said = []
        self.properties = {}

    def say(self, text):
        self.said.append(text)

    def runAndWait(self):
        pass

    def setProperty(self, name, value):
        self.properties[name] = value


class BrokenEngine:
    """Simulates a speech engine that dies on speak."""

    def say(self, text):
        raise RuntimeError("audio device vanished")

    def runAndWait(self):
        pass

    def setProperty(self, name, value):
        pass


def make_speaker(**overrides):
    """Build a Speaker wired to a FakeEngine, with test-friendly defaults."""
    engine = FakeEngine()
    kwargs = {"engine_factory": lambda: engine}
    kwargs.update(overrides)
    return speaker_module.Speaker(**kwargs), engine


class TestSpeaker(unittest.TestCase):

    def test_speaks_reply(self):
        spk, engine = make_speaker()
        self.assertTrue(spk.speak("Greetings."))
        self.assertEqual(engine.said, ["Greetings."])

    def test_engine_created_lazily_and_rate_applied(self):
        created = []

        def factory():
            engine = FakeEngine()
            created.append(engine)
            return engine

        spk = speaker_module.Speaker(rate=160, engine_factory=factory)
        self.assertEqual(created, [])  # nothing until first speak
        spk.speak("hello")
        self.assertEqual(len(created), 1)
        self.assertEqual(created[0].properties["rate"], 160)

    def test_duplicate_consecutive_reply_skipped(self):
        spk, engine = make_speaker()
        spk.speak("All systems nominal.")
        spk.speak("All systems nominal.")
        self.assertEqual(engine.said, ["All systems nominal."])
        # A different reply still speaks.
        spk.speak("Ready.")
        self.assertEqual(len(engine.said), 2)

    def test_long_reply_truncated_at_word_boundary(self):
        spk, engine = make_speaker(max_chars=20)
        spk.speak("alpha beta gamma delta epsilon")
        self.assertEqual(engine.said, ["alpha beta gamma..."])
        self.assertNotIn(" epsilon", engine.said[0])

    def test_multiline_help_collapsed_to_one_line(self):
        spk, engine = make_speaker()
        spk.speak("Built-in commands:\n  help   Show list\n  exit   Quit")
        self.assertEqual(engine.said,
                         ["Built-in commands: help Show list exit Quit"])

    def test_disabled_speaker_is_silent(self):
        created = []

        def factory():
            created.append(True)
            return FakeEngine()

        spk = speaker_module.Speaker(enabled=False, engine_factory=factory)
        self.assertFalse(spk.speak("hello"))
        self.assertEqual(created, [])  # engine never even initialized

    def test_empty_text_not_spoken(self):
        spk, engine = make_speaker()
        self.assertFalse(spk.speak("   \n  "))
        self.assertEqual(engine.said, [])

    def test_force_repeats_identical_reply(self):
        spk, engine = make_speaker()
        self.assertTrue(spk.speak("Local time: 9:05."))
        self.assertFalse(spk.speak("Local time: 9:05."))  # deduped
        # The 'speak' command uses force=True to re-read the same text.
        self.assertTrue(spk.speak("Local time: 9:05.", force=True))
        self.assertEqual(engine.said,
                         ["Local time: 9:05.", "Local time: 9:05."])

    def test_engine_failure_disables_speech_without_crashing(self):
        spk = speaker_module.Speaker(engine_factory=lambda: BrokenEngine())
        self.assertFalse(spk.speak("hello"))  # must not raise
        self.assertTrue(spk._failed)
        # Subsequent calls stay silent and still never raise.
        self.assertFalse(spk.speak("again"))

    def test_set_enabled_toggles(self):
        spk, engine = make_speaker(enabled=False)
        spk.set_enabled(True)
        self.assertTrue(spk.speak("back on"))
        spk.set_enabled(False)
        self.assertFalse(spk.speak("silent again"))
        self.assertEqual(engine.said, ["back on"])


class TestHelpers(unittest.TestCase):

    def test_clean(self):
        self.assertEqual(speaker_module._clean(" a\n b\t c "), "a b c")

    def test_truncate_short_unchanged(self):
        self.assertEqual(speaker_module._truncate("short", 10), "short")

    def test_truncate_zero_disables(self):
        self.assertEqual(speaker_module._truncate("anything", 0), "anything")


class TestSharedSpeaker(unittest.TestCase):

    def tearDown(self):
        speaker_module.reset_speaker_for_tests()

    def test_get_speaker_singleton_uses_config(self):
        class FakeConfig:
            SPEAK_RESPONSES = False
            SPEECH_RATE = 120
            SPEECH_MAX_CHARS = 500

        first = speaker_module.get_speaker(FakeConfig)
        second = speaker_module.get_speaker(FakeConfig)
        self.assertIs(first, second)
        self.assertFalse(first.enabled)
        self.assertEqual(first.rate, 120)
        self.assertEqual(first.max_chars, 500)


if __name__ == "__main__":
    unittest.main()