"""Tests for local command parsing (offline, standard library only)."""

import unittest

from brain import intent


class TestIntent(unittest.TestCase):

    def test_basic_commands(self):
        self.assertEqual(intent.parse("help"), ("help", ""))
        self.assertEqual(intent.parse("HELP"), ("help", ""))
        self.assertEqual(intent.parse("exit"), ("exit", ""))

    def test_aliases(self):
        self.assertEqual(intent.parse("quit"), ("exit", ""))
        self.assertEqual(intent.parse("q"), ("exit", ""))
        self.assertEqual(intent.parse("bye"), ("exit", ""))

    def test_new_commands(self):
        self.assertEqual(intent.parse("time"), ("time", ""))
        self.assertEqual(intent.parse("date"), ("date", ""))
        self.assertEqual(intent.parse("history"), ("history", ""))
        self.assertEqual(intent.parse("speak"), ("speak", ""))

    def test_speak_word_aliases(self):
        self.assertEqual(intent.parse("again"), ("speak", ""))
        self.assertEqual(intent.parse("repeat"), ("speak", ""))

    def test_speak_phrase_aliases(self):
        for phrase in ("read it aloud", "Read it aloud!", "Read it aloud!!!",
                       "say that again", "say that again.",
                       "  say   that   AGAIN!!  ",
                       "say it again", "repeat that", "repeat it",
                       "  SAY   THAT   AGAIN  "):
            command, remainder = intent.parse(phrase)
            self.assertEqual(command, "speak", phrase)
            self.assertEqual(remainder, "", phrase)

    def test_punctuated_single_word_commands(self):
        self.assertEqual(intent.parse("help!"), ("help", ""))
        self.assertEqual(intent.parse("time?"), ("time", ""))
        self.assertEqual(intent.parse("speak."), ("speak", ""))
        self.assertEqual(intent.parse("again?"), ("speak", ""))

    def test_normalize_is_a_separate_copy(self):
        original = "  Read   it ALoud!!!  "
        normalized = intent.normalize_for_command(original)
        self.assertEqual(normalized, "read it aloud")
        # The original input string is untouched (history shows it as typed).
        self.assertEqual(original, "  Read   it ALoud!!!  ")
        # Normalization never returns the same object.
        self.assertIsNot(normalized, original)

    def test_parse_does_not_modify_input(self):
        original = "Calc 2 + 2."
        intent.parse(original)
        self.assertEqual(original, "Calc 2 + 2.")

    def test_phrase_aliases_do_not_shadow_longer_input(self):
        # "read it aloud please" is NOT the exact alias phrase.
        self.assertEqual(intent.parse("read it aloud please"),
                         (None, "read it aloud please"))

    def test_command_with_argument(self):
        self.assertEqual(intent.parse("calc 2 + 2"), ("calc", "2 + 2"))

    def test_greeting_is_not_a_command(self):
        # Greetings are handled by brain/conversation.py, not intent.
        self.assertEqual(intent.parse("hi"), (None, "hi"))
        self.assertEqual(intent.parse("hello"), (None, "hello"))

    def test_empty_input(self):
        self.assertEqual(intent.parse(""), (None, ""))
        self.assertEqual(intent.parse("   "), (None, ""))

    def test_every_command_has_description(self):
        for name, description in intent.COMMANDS.items():
            self.assertTrue(description, "missing description for " + name)


if __name__ == "__main__":
    unittest.main()
