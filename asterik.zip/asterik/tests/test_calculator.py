"""Tests for the safe arithmetic parser (no eval)."""

import unittest

from brain import calculator


class TestEvaluate(unittest.TestCase):

    def test_basic_operations(self):
        self.assertEqual(calculator.evaluate("2 + 2"), 4)
        self.assertEqual(calculator.evaluate("10 - 3"), 7)
        self.assertEqual(calculator.evaluate("3 * 4"), 12)
        self.assertEqual(calculator.evaluate("7 / 2"), 3.5)

    def test_precedence_and_parentheses(self):
        self.assertEqual(calculator.evaluate("2 + 3 * 4"), 14)
        self.assertEqual(calculator.evaluate("(2 + 3) * 4"), 20)
        self.assertEqual(calculator.evaluate("2 ** 3 ** 2"), 512)  # right-assoc

    def test_unary_minus_and_decimals(self):
        self.assertEqual(calculator.evaluate("-5 + 10"), 5)
        self.assertEqual(calculator.evaluate("2.5 * 2"), 5)
        self.assertEqual(calculator.evaluate(".5 + .5"), 1)

    def test_floor_division_and_modulo(self):
        self.assertEqual(calculator.evaluate("7 // 2"), 3)
        self.assertEqual(calculator.evaluate("7 % 3"), 1)

    def test_division_by_zero(self):
        with self.assertRaises(calculator.CalcError):
            calculator.evaluate("1 / 0")
        with self.assertRaises(calculator.CalcError):
            calculator.evaluate("5 % 0")

    def test_rejects_non_math_input(self):
        # The whole point: no code execution, only numbers and operators.
        for hostile in ("__import__('os')", "open('x')", "2 + hello", "abc"):
            with self.assertRaises(calculator.CalcError):
                calculator.evaluate(hostile)

    def test_rejects_unbalanced_parentheses(self):
        with self.assertRaises(calculator.CalcError):
            calculator.evaluate("(2 + 2")
        with self.assertRaises(calculator.CalcError):
            calculator.evaluate("2 + 2)")

    def test_trailing_operator(self):
        with self.assertRaises(calculator.CalcError):
            calculator.evaluate("2 +")

    def test_empty_expression(self):
        with self.assertRaises(calculator.CalcError):
            calculator.evaluate("   ")


class TestHelpers(unittest.TestCase):

    def test_is_math_like(self):
        self.assertTrue(calculator.is_math_like("2 + 2"))
        self.assertTrue(calculator.is_math_like("10/4"))
        self.assertFalse(calculator.is_math_like("hello there"))
        self.assertFalse(calculator.is_math_like("+ - *"))

    def test_try_evaluate_never_raises(self):
        ok, value, error = calculator.try_evaluate("2 * 3")
        self.assertTrue(ok)
        self.assertEqual(value, 6)
        self.assertIsNone(error)

        ok, value, error = calculator.try_evaluate("2 *")
        self.assertFalse(ok)
        self.assertIsNone(value)
        self.assertTrue(error)

    def test_format_number(self):
        self.assertEqual(calculator.format_number(4.0), "4")
        self.assertEqual(calculator.format_number(3.5), "3.5")


if __name__ == "__main__":
    unittest.main()
