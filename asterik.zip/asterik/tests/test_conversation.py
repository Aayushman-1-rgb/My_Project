"""Tests for offline conversation features (greetings, fallback, history)."""

import unittest

from brain import conversation


class TestGreetings(unittest.TestCase):

    def test_common_greetings(self):
        for text in ("hi", "Hello!", "hey", "good morning", "HOW ARE YOU?",
                     "hi there", "greetings"):
            self.assertTrue(conversation.is_greeting(text), text)

    def test_non_greetings(self):
        for text in ("tell me a joke", "what is your name", "calc 2 + 2", ""):
            self.assertFalse(conversation.is_greeting(text), text)

    def test_greeting_replies(self):
        reply = conversation.greeting_reply("hi", "ASTERIK")
        self.assertIn("ASTERIK", reply)
        wellness = conversation.greeting_reply("how are you", "ASTERIK")
        self.assertIn("nominal", wellness)


class TestIdentity(unittest.TestCase):

    def test_identity_questions(self):
        for text in ("what is your name?", "Who are you?", "what can you do",
                     "what is your purpose"):
            self.assertTrue(conversation.is_identity_question(text), text)

    def test_identity_reply(self):
        reply = conversation.identity_reply("ASTERIK", "0.1.0")
        self.assertIn("ASTERIK", reply)
        self.assertIn("0.1.0", reply)


class TestUnknownReply(unittest.TestCase):

    def test_mentions_help_and_does_not_nag(self):
        session = conversation.Session()
        reply = conversation.unknown_reply("ASTERIK", session)
        self.assertIn("help", reply)
        self.assertNotIn("AI is disabled", reply)

    def test_varies_with_session(self):
        session = conversation.Session()
        first = conversation.unknown_reply("ASTERIK", session)
        session.record("user", "random text")
        session.record("assistant", first)
        second = conversation.unknown_reply("ASTERIK", session)
        self.assertNotEqual(first, second)


class TestSession(unittest.TestCase):

    def test_record_and_recent(self):
        session = conversation.Session()
        session.record("user", "hi")
        session.record("assistant", "Greetings.")
        self.assertEqual(len(session), 2)
        entries = session.recent()
        self.assertEqual(entries[0], ("user", "hi"))
        self.assertEqual(entries[1], ("assistant", "Greetings."))

    def test_ignores_empty(self):
        session = conversation.Session()
        session.record("user", "   ")
        self.assertEqual(len(session), 0)

    def test_cap_at_max_entries(self):
        session = conversation.Session(max_entries=3)
        for index in range(5):
            session.record("user", str(index))
        self.assertEqual(len(session), 3)
        # Oldest entries were dropped.
        self.assertEqual(session.recent(3), [("user", "2"), ("user", "3"),
                                             ("user", "4")])


if __name__ == "__main__":
    unittest.main()
